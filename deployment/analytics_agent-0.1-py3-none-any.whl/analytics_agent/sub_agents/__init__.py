from .reporting.agent import root_agent as Analytics_agent



__all__ = ["Analytics_agent"]
